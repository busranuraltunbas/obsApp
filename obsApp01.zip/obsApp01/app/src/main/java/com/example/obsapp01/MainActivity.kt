package com.example.obsapp01

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import android.widget.CheckBox




class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val button : Button = findViewById(R.id.btnGirisYap)
        button.setOnClickListener {
            var girisUserName = girisKullaniciAdi.text.toString()
            var girisParola = girisParola.text.toString()

            if(girisUserName.trim()!="" && girisParola.trim()!=""){
                if(girisUserName.trim() == "admin" && girisParola.trim() == "admin"){
                    val intent = Intent(this, AdminPaneli::class.java)
                    startActivity(intent)
                }

                /*if(checkBox.isChecked()){

                    val intent = Intent(this, TeacherMenu::class.java)
                    startActivity(intent)
                    Toast.makeText(this,  "Yetkili Sayfası", Toast.LENGTH_SHORT).show()
                }
                else{
                    val intent = Intent(this, StudentMenu::class.java)
                    startActivity(intent)aenci Sayfası", Toast.LENGTH_SHORT).show()
                }*/
            }else{
                Toast.makeText(applicationContext,"Tüm alanlar doldurulmalı",Toast.LENGTH_LONG).show()
            }


            //Toast.makeText(this,  "Giriş Yapıldı ", Toast.LENGTH_SHORT).show()
        }

    }
}