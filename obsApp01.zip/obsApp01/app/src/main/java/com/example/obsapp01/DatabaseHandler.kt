import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.content.ContentValues
import android.database.Cursor
import android.database.sqlite.SQLiteException
import com.example.obsapp01.UsersModel

// this method create local database with SQLiteOpenHelper
class DatabaseHandler(context: Context): SQLiteOpenHelper(context,DATABASE_NAME,null,DATABASE_VERSION) {
    companion object {
        private val DATABASE_VERSION = 1
        private val DATABASE_NAME = "DatabaseTest"
        private val MAIN_TABLE = "Ogrenciler"
        private val KEY_ID = "id"
        private val KEY_NAME = "name"
        private val KEY_EMAIL = "email"
        private val KEY_ROLE = "status"
    }
    override fun onCreate(db: SQLiteDatabase?) {
        val CREATE_CONTACTS_TABLE = ("CREATE TABLE " + MAIN_TABLE + "("
                + KEY_ID + " INTEGER PRIMARY KEY," + KEY_NAME + " TEXT,"
                + KEY_EMAIL + " TEXT," + KEY_ROLE + " INTEGER" + ")")
        db?.execSQL(CREATE_CONTACTS_TABLE)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db!!.execSQL("DROP TABLE IF EXISTS " + MAIN_TABLE)
        onCreate(db)
    }


    //this method insert data
    fun addEmployee(student: UsersModel):Long{
        val db = this.writableDatabase
        val contentValues = ContentValues()
        contentValues.put(KEY_ID, student.userId)
        contentValues.put(KEY_NAME, student.userName)
        contentValues.put(KEY_EMAIL,student.userEmail )
        contentValues.put(KEY_ROLE,student.userRole)
        val success = db.insert(MAIN_TABLE, null, contentValues)
        db.close()
        return success
    }
    //this method to read data
    fun viewEmployee():List<UsersModel>{
        val studentList:ArrayList<UsersModel> = ArrayList<UsersModel>()
        val selectQuery = "SELECT  * FROM $MAIN_TABLE"
        val db = this.readableDatabase
        var cursor: Cursor? = null
        try{
            cursor = db.rawQuery(selectQuery, null)
        }catch (e: SQLiteException) {
            db.execSQL(selectQuery)
            return ArrayList()
        }
        var userId: Int
        var userName: String
        var userEmail: String
        var userRole : Int
        if (cursor.moveToFirst()) {
            do {
                userId = cursor.getInt(cursor.getColumnIndexOrThrow("id"))
                userName = cursor.getString(cursor.getColumnIndexOrThrow("name"))
                userEmail = cursor.getString(cursor.getColumnIndexOrThrow("email"))
                userRole = cursor.getInt(cursor.getColumnIndexOrThrow("status"))

                val student= UsersModel(userId = userId, userName = userName, userEmail = userEmail, userRole = userRole)
                studentList.add(student)
            } while (cursor.moveToNext())
        }
        return studentList
    }
    //this method update data
    fun updateEmployee(student: UsersModel):Int{
        val db = this.writableDatabase
        val contentValues = ContentValues()
        contentValues.put(KEY_ID, student.userId)
        contentValues.put(KEY_NAME, student.userName)
        contentValues.put(KEY_EMAIL,student.userEmail )

        val success = db.update(MAIN_TABLE, contentValues,"id="+student.userId,null)
        db.close()
        return success
    }
    //this method delete  data
    fun deleteEmployee(student: UsersModel):Int{
        val db = this.writableDatabase
        val contentValues = ContentValues()
        contentValues.put(KEY_ID, student.userId)
        val success = db.delete(MAIN_TABLE,"id="+student.userId,null)
        db.close()
        return success
    }
}