package com.example.obsapp01

import DatabaseHandler
import android.content.DialogInterface
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.Switch
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import kotlinx.android.synthetic.main.activity_admin_paneli.*


class AdminPaneli : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin_paneli)


    }
    // this method for save records to database
    fun saveRecord(view: View){
        val id = u_id.text.toString()
        val name = u_name.text.toString()
        val email = u_email.text.toString()
        var role : Switch = findViewById(R.id.u_role)
        val switchState: Boolean = role.isChecked()


        val databaseHandler: DatabaseHandler= DatabaseHandler(this)
        if(id.trim()!="" && name.trim()!="" && email.trim()!=""){

            if(switchState){
                val status = databaseHandler.addEmployee(UsersModel(Integer.parseInt(id),name, email, 1))
                if(status > -1){
                    Toast.makeText(this,"Kullanıcı Kaydedildi",Toast.LENGTH_LONG).show()
                    u_id.text.clear()
                    u_name.text.clear()
                    u_email.text.clear()
                    //u_role.text.clear()
                }
            }
            else{
                val status = databaseHandler.addEmployee(UsersModel(Integer.parseInt(id),name, email, 0))
                if(status > -1){
                    Toast.makeText(this,"Kullanıcı Kaydedildi",Toast.LENGTH_LONG).show()
                    u_id.text.clear()
                    u_name.text.clear()
                    u_email.text.clear()
                    //u_role.text.clear()
                }
            }

        }else{
            Toast.makeText(this,"Tüm alanlar doldurulmalı",Toast.LENGTH_LONG).show()
        }

    }
    // this method for read records from database in ListView
    fun viewRecord(view: View){
        //creating the instance of DatabaseHandler class
        val databaseHandler: DatabaseHandler= DatabaseHandler(this)
        val student: List<UsersModel> = databaseHandler.viewEmployee()
        val studentArrayId = Array<String>(student.size){"0"}
        val studentArrayName = Array<String>(student.size){"null"}
        val studentArrayEmail = Array<String>(student.size){"null"}
        val studentArrayStatus = Array<String>(student.size){"0"}
        var index = 0
        for(e in student){
            studentArrayId[index] = e.userId.toString()
            studentArrayName[index] = e.userName
            studentArrayEmail[index] = e.userEmail
            studentArrayStatus[index] = e.userRole.toString()
            index++
        }

        val myListAdapter = ListAdapter(this,studentArrayId,studentArrayName,studentArrayEmail,studentArrayStatus)
        listView.adapter = myListAdapter
    }

    // this method update record from database
    fun updateRecord(view: View){
        val dialogBuilder = AlertDialog.Builder(this)
        val inflater = this.layoutInflater
        val dialogView = inflater.inflate(R.layout.update_dialog, null)
        dialogBuilder.setView(dialogView)

        val edtId = dialogView.findViewById(R.id.updateId) as EditText
        val edtName = dialogView.findViewById(R.id.updateName) as EditText
        val edtEmail = dialogView.findViewById(R.id.updateEmail) as EditText


        //val edtRole = dialogView.findViewById(R.id.updateRole) as EditText

        dialogBuilder.setTitle("Kaydı Güncelle")
        dialogBuilder.setMessage("Bilgileri Giriniz")
        dialogBuilder.setPositiveButton("Güncelle", DialogInterface.OnClickListener { _, _ ->

            val updateId = edtId.text.toString()
            val updateName = edtName.text.toString()
            val updateEmail = edtEmail.text.toString()
            //val updateRole= edtRole.text.toString()
            //creating the instance of DatabaseHandler class
            val databaseHandler: DatabaseHandler= DatabaseHandler(this)
            if(updateId.trim()!="" && updateName.trim()!="" && updateEmail.trim()!=""){
                //calling the updateEmployee method of DatabaseHandler class to update record
                val status = databaseHandler.updateEmployee(UsersModel(Integer.parseInt(updateId),updateName, updateEmail, 0))
                if(status > -1){
                    Toast.makeText(applicationContext,"Kayıt Güncellendi",Toast.LENGTH_LONG).show()
                }
            }else{
                Toast.makeText(this,"Tüm alanlar doldurulmalı",Toast.LENGTH_LONG).show()
            }

        })
        dialogBuilder.setNegativeButton("Çıkış", DialogInterface.OnClickListener { dialog, which ->
            //pass
        })
        val b = dialogBuilder.create()
        b.show()
    }
    //method for deleting records based on id
    fun deleteRecord(view: View){
        //creating AlertDialog for taking user id
        val dialogBuilder = AlertDialog.Builder(this)
        val inflater = this.layoutInflater
        val dialogView = inflater.inflate(R.layout.delete_dialog, null)
        dialogBuilder.setView(dialogView)

        val dltId = dialogView.findViewById(R.id.deleteId) as EditText
        dialogBuilder.setTitle("Kaydı Sil")
        dialogBuilder.setMessage("Öğrenci Numarası Giriniz")
        dialogBuilder.setPositiveButton("Sil", DialogInterface.OnClickListener { _, _ ->

            val deleteId = dltId.text.toString()
            //creating the instance of DatabaseHandler class
            val databaseHandler: DatabaseHandler= DatabaseHandler(this)
            if(deleteId.trim()!=""){
                //calling the deleteEmployee method of DatabaseHandler class to delete record
                val status = databaseHandler.deleteEmployee(UsersModel(Integer.parseInt(deleteId),"","", userRole = 0))
                if(status > -1){
                    Toast.makeText(this,"Kayıt Silindi",Toast.LENGTH_LONG).show()
                }
            }else{
                Toast.makeText(applicationContext,"Tüm alanlar doldurulmalı\"",Toast.LENGTH_LONG).show()
            }

        })
        dialogBuilder.setNegativeButton("Çıkış", DialogInterface.OnClickListener { _, _ ->
        })
        val b = dialogBuilder.create()
        b.show()
    }

    fun signOut(view: View){
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
    }
}