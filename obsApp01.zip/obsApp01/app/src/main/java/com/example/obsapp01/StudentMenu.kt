package com.example.obsapp01

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class StudentMenu : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_student_menu)
    }
}